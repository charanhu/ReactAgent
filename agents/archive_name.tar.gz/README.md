# Langchain Course 5, LangGraph

Information for Engineering:
- this uses openai gpt-4-turbo AND gpt-4o And gpt-3.5-turbo models, the proxy will need to be adapted to allow this for this course
  - note, lab 4 does not run correctly with 3.5
- this uses the tavily api, Geoff can provide this Key which is provided by Tavily CEO Rotem Weiss
- this uses a package for graphing that needs to be apt-get'ed. This is noted in the requirements.txt file in a comment



